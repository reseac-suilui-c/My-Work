# `@react-navigation/compat`

Compatibility layer to write navigator definitions in static configuration format.

Installation instructions and documentation can be found on the [React Navigation website](https://reactnavigation.org/docs/compatibility/).
