# `@react-navigation/bottom-tabs`

Bottom tab navigator for React Navigation following iOS design guidelines.

Installation instructions and documentation can be found on the [React Navigation website](https://reactnavigation.org/docs/bottom-tab-navigator/).
