import * as React from 'react';

const DrawerOpenContext = React.createContext<boolean | null>(null);

export default DrawerOpenContext;
