import * as React from 'react';

export default React.createContext<React.RefObject<any> | null>(null);
