import * as React from 'react';

export default React.createContext<'left' | 'right' | undefined>(undefined);
