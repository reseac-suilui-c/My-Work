# `@react-navigation/drawer`

Drawer navigator for React Navigation following Material Design guidelines. 

Installation instructions and documentation can be found on the [React Navigation website](https://reactnavigation.org/docs/drawer-navigator/).
