import * as React from 'react';

const HeaderShownContext = React.createContext(false);

export default HeaderShownContext;
