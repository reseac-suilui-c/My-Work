import * as React from 'react';

export default React.createContext<number | undefined>(undefined);
