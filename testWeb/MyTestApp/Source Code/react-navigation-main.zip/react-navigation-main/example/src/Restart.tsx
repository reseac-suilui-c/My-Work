export function restartApp() {}
