import * as Linking from 'expo-linking';
export default [Linking.makeUrl('/')];
