// @ts-expect-error: there are no type definitions for deep imports
import TouchableBounce from 'react-native/Libraries/Components/Touchable/TouchableBounce';

export default TouchableBounce;
