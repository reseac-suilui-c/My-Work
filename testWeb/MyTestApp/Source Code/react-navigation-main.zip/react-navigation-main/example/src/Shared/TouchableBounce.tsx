import { TouchableOpacity } from 'react-native';

export default TouchableOpacity;
