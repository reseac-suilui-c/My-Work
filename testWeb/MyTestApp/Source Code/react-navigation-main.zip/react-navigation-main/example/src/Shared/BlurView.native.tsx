import { BlurView } from 'expo-blur';

export default BlurView;
