import React, { Component } from 'react';

import RootNavigator from './rootNavigator';

export default class App extends Component {
    render() {
        return (
            <RootNavigator/>
        );
    }
}